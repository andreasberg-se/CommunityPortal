﻿namespace CommunityPortal.Models
{
    public class RSSFeedSubs
    {
    }
}
