﻿namespace CommunityPortal.Models.React
{
    public class GetAllUsers
    {
        public string Id { get; set; }

        public string UserName { get; set; }
    }
}
