### started by the .NET 5.0 project

can be manually invoked by ``npm run start``