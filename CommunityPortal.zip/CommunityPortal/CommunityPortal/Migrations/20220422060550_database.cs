﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace CommunityPortal.Migrations
{
    public partial class database : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "AspNetRoles",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    NormalizedName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    ConcurrencyStamp = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetRoles", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUsers",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    UserName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    NormalizedUserName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    Email = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    NormalizedEmail = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    EmailConfirmed = table.Column<bool>(type: "bit", nullable: false),
                    PasswordHash = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SecurityStamp = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ConcurrencyStamp = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PhoneNumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PhoneNumberConfirmed = table.Column<bool>(type: "bit", nullable: false),
                    TwoFactorEnabled = table.Column<bool>(type: "bit", nullable: false),
                    LockoutEnd = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    LockoutEnabled = table.Column<bool>(type: "bit", nullable: false),
                    AccessFailedCount = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUsers", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Categories",
                columns: table => new
                {
                    CategoryId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Title = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Categories", x => x.CategoryId);
                });

            migrationBuilder.CreateTable(
                name: "DeviceCodes",
                columns: table => new
                {
                    UserCode = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    DeviceCode = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    SubjectId = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    SessionId = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    ClientId = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    Description = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Expiration = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Data = table.Column<string>(type: "nvarchar(max)", maxLength: 50000, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DeviceCodes", x => x.UserCode);
                });

            migrationBuilder.CreateTable(
                name: "DiscussionCategories",
                columns: table => new
                {
                    DiscussionCategoryId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DiscussionCategories", x => x.DiscussionCategoryId);
                });

            migrationBuilder.CreateTable(
                name: "DiscussionGroup",
                columns: table => new
                {
                    DiscussionGroupId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DiscussionGroupName = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DiscussionGroup", x => x.DiscussionGroupId);
                });

            migrationBuilder.CreateTable(
                name: "PersistedGrants",
                columns: table => new
                {
                    Key = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    Type = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    SubjectId = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    SessionId = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    ClientId = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    Description = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Expiration = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ConsumedTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Data = table.Column<string>(type: "nvarchar(max)", maxLength: 50000, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PersistedGrants", x => x.Key);
                });

            migrationBuilder.CreateTable(
                name: "AspNetRoleClaims",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RoleId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ClaimType = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ClaimValue = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetRoleClaims", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AspNetRoleClaims_AspNetRoles_RoleId",
                        column: x => x.RoleId,
                        principalTable: "AspNetRoles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserClaims",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ClaimType = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ClaimValue = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserClaims", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AspNetUserClaims_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserLogins",
                columns: table => new
                {
                    LoginProvider = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ProviderKey = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ProviderDisplayName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserLogins", x => new { x.LoginProvider, x.ProviderKey });
                    table.ForeignKey(
                        name: "FK_AspNetUserLogins_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserRoles",
                columns: table => new
                {
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    RoleId = table.Column<string>(type: "nvarchar(450)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserRoles", x => new { x.UserId, x.RoleId });
                    table.ForeignKey(
                        name: "FK_AspNetUserRoles_AspNetRoles_RoleId",
                        column: x => x.RoleId,
                        principalTable: "AspNetRoles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_AspNetUserRoles_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserTokens",
                columns: table => new
                {
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    LoginProvider = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Value = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserTokens", x => new { x.UserId, x.LoginProvider, x.Name });
                    table.ForeignKey(
                        name: "FK_AspNetUserTokens_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ReceivedPrivateMessages",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Subject = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Message = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ReceiverId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ReceiverUserName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SenderId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SenderUserName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TimeReceived = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ReceivedPrivateMessages", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ReceivedPrivateMessages_AspNetUsers_ReceiverId",
                        column: x => x.ReceiverId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "SentPrivateMessages",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Subject = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Message = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ReceiverId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ReceiverUserName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SenderId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    SenderUserName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TimeSent = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SentPrivateMessages", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SentPrivateMessages_AspNetUsers_SenderId",
                        column: x => x.SenderId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "NewsPosts",
                columns: table => new
                {
                    NewsPostId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    IsEvent = table.Column<bool>(type: "bit", nullable: false),
                    Tag = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Heading = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Information = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CategoryId = table.Column<int>(type: "int", nullable: false),
                    UserName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedDate = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_NewsPosts", x => x.NewsPostId);
                    table.ForeignKey(
                        name: "FK_NewsPosts_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_NewsPosts_Categories_CategoryId",
                        column: x => x.CategoryId,
                        principalTable: "Categories",
                        principalColumn: "CategoryId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "DiscussionForums",
                columns: table => new
                {
                    DiscussionForumId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DiscussionCategoryId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DiscussionForums", x => x.DiscussionForumId);
                    table.ForeignKey(
                        name: "FK_DiscussionForums_DiscussionCategories_DiscussionCategoryId",
                        column: x => x.DiscussionCategoryId,
                        principalTable: "DiscussionCategories",
                        principalColumn: "DiscussionCategoryId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "DiscussionGroupCategory",
                columns: table => new
                {
                    DiscussionGroupId = table.Column<int>(type: "int", nullable: false),
                    DiscussionCategoryId = table.Column<int>(type: "int", nullable: false),
                    DiscussionGroupCategoryId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DiscussionGroupCategory", x => new { x.DiscussionGroupId, x.DiscussionCategoryId });
                    table.ForeignKey(
                        name: "FK_DiscussionGroupCategory_DiscussionCategories_DiscussionCategoryId",
                        column: x => x.DiscussionCategoryId,
                        principalTable: "DiscussionCategories",
                        principalColumn: "DiscussionCategoryId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_DiscussionGroupCategory_DiscussionGroup_DiscussionGroupId",
                        column: x => x.DiscussionGroupId,
                        principalTable: "DiscussionGroup",
                        principalColumn: "DiscussionGroupId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "DiscussionTopics",
                columns: table => new
                {
                    DiscussionTopicId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DiscussionForumId = table.Column<int>(type: "int", nullable: false),
                    Subject = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Content = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Time = table.Column<DateTime>(type: "datetime2", nullable: false),
                    AuthorId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    NrOfViews = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DiscussionTopics", x => x.DiscussionTopicId);
                    table.ForeignKey(
                        name: "FK_DiscussionTopics_AspNetUsers_AuthorId",
                        column: x => x.AuthorId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_DiscussionTopics_DiscussionForums_DiscussionForumId",
                        column: x => x.DiscussionForumId,
                        principalTable: "DiscussionForums",
                        principalColumn: "DiscussionForumId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "DiscussionGroupMemberships",
                columns: table => new
                {
                    CommunityUserId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    DiscussionGroupId = table.Column<int>(type: "int", nullable: false),
                    DiscussionGroupMembershipId = table.Column<int>(type: "int", nullable: false),
                    CommunityUserId1 = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    DiscussionCategoryId = table.Column<int>(type: "int", nullable: true),
                    DiscussionGroupCategoryDiscussionCategoryId = table.Column<int>(type: "int", nullable: true),
                    DiscussionGroupCategoryDiscussionGroupId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DiscussionGroupMemberships", x => new { x.CommunityUserId, x.DiscussionGroupId });
                    table.ForeignKey(
                        name: "FK_DiscussionGroupMemberships_AspNetUsers_CommunityUserId",
                        column: x => x.CommunityUserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_DiscussionGroupMemberships_AspNetUsers_CommunityUserId1",
                        column: x => x.CommunityUserId1,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_DiscussionGroupMemberships_DiscussionCategories_DiscussionCategoryId",
                        column: x => x.DiscussionCategoryId,
                        principalTable: "DiscussionCategories",
                        principalColumn: "DiscussionCategoryId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_DiscussionGroupMemberships_DiscussionGroup_DiscussionGroupId",
                        column: x => x.DiscussionGroupId,
                        principalTable: "DiscussionGroup",
                        principalColumn: "DiscussionGroupId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_DiscussionGroupMemberships_DiscussionGroupCategory_DiscussionGroupCategoryDiscussionGroupId_DiscussionGroupCategoryDiscussio~",
                        columns: x => new { x.DiscussionGroupCategoryDiscussionGroupId, x.DiscussionGroupCategoryDiscussionCategoryId },
                        principalTable: "DiscussionGroupCategory",
                        principalColumns: new[] { "DiscussionGroupId", "DiscussionCategoryId" },
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "DiscussionReplies",
                columns: table => new
                {
                    DiscussionReplyId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TopicId = table.Column<int>(type: "int", nullable: false),
                    Content = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Time = table.Column<DateTime>(type: "datetime2", nullable: false),
                    AuthorId = table.Column<string>(type: "nvarchar(450)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DiscussionReplies", x => x.DiscussionReplyId);
                    table.ForeignKey(
                        name: "FK_DiscussionReplies_AspNetUsers_AuthorId",
                        column: x => x.AuthorId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_DiscussionReplies_DiscussionTopics_TopicId",
                        column: x => x.TopicId,
                        principalTable: "DiscussionTopics",
                        principalColumn: "DiscussionTopicId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[,]
                {
                    { "71ee5627-d5d3-456c-b7be-c975cb25de70", "a5ede231-d4ac-43eb-8486-e585649de1df", "Admin", "ADMIN" },
                    { "37bf4465-d811-49a8-821b-40055b62de42", "f7ff4d2b-c416-475b-bd1f-17449a285c3e", "Moderator", "MODERATOR" },
                    { "7e1ca1bc-a0bb-4380-aac7-892d778b9de6", "a4454fdb-c9d7-41a5-a2af-9f139436fe42", "User", "USER" }
                });

            migrationBuilder.InsertData(
                table: "AspNetUsers",
                columns: new[] { "Id", "AccessFailedCount", "ConcurrencyStamp", "Email", "EmailConfirmed", "LockoutEnabled", "LockoutEnd", "NormalizedEmail", "NormalizedUserName", "PasswordHash", "PhoneNumber", "PhoneNumberConfirmed", "SecurityStamp", "TwoFactorEnabled", "UserName" },
                values: new object[,]
                {
                    { "fd788a3b-ae7d-46b4-a7dc-ac035df8ff94", 0, "8d930fb9-ad90-49f3-92ae-273de38de0ef", "user@b.com", false, false, null, "USER@B.COM", "USER@B.COM", "AQAAAAEAACcQAAAAEPwXx9Ec1KImMUMdmMmQ0Ms0fVDD9cX72rr2xOfadJxn2rNwmfi69f74xezdJK8Pmg==", null, false, "12c105b2-0fd5-453e-b916-b8d475256779", false, "user@b.com" },
                    { "3b78c692-6b1f-46e6-81fc-8705c97db0b6", 0, "c8e11c1f-f37f-48f2-aa7a-3da7ee0bee40", "moderator@b.com", false, false, null, "MODERATOR@B.COM", "MODERATOR@B.COM", "AQAAAAEAACcQAAAAEDKO7FR/R6ZqxJFfuGv2NU+FLtKNJRDMMYuiKQ/E5SMNLhbriiVHNHhiLjjG0LuM0Q==", null, false, "41b4fc56-60a9-4ff3-80de-de4eee288259", false, "moderator@b.com" },
                    { "f8ac842f-64ad-4caf-b54f-fc964577e56d", 0, "8aa6e0c5-6f9b-48d6-957d-b62d4c582bea", "admin@b.com", false, false, null, "ADMIN@B.COM", "ADMIN@B.COM", "AQAAAAEAACcQAAAAEJT86Sf98oWpKw+NzLvtdnDuRn8Aw25aIDvtqjWVOgHAdtDH1xSI4dI4CorBxpDZmg==", null, false, "2f80713e-8cee-434a-9d70-1d4a589bad8e", false, "admin@b.com" },
                    { "e205bfd7-c4ac-47a8-816a-1e1001f9ab30", 0, "f7c47e52-58c6-4296-87bc-5e1e3f14a79c", "tobias@b.com", false, false, null, "TOBIAS@B.COM", "TOBIAS@B.COM", "AQAAAAEAACcQAAAAEFGQboco4/y0d/78Pwv1nSSwBoaSf5jYT/3T5cTJa+SXW43Z8vCItIj9MbKqtAfIFA==", null, false, "a0b4c9ba-4477-40f8-be76-513b1d2aee1a", false, "tobias@b.com" },
                    { "da84c209-09ce-4dae-82a9-ec65d0920f0c", 0, "3b0f0669-18b1-4e75-91bf-52637ffc92f9", "peter@b.com", false, false, null, "PETER@B.COM", "PETER@B.COM", "AQAAAAEAACcQAAAAEAQAGM1Qy7Gjak9Bc09bq2AYmmVW7OVBlXd0gk/gFffNyo7LvL4bl02t++0rjd8Rlg==", null, false, "bb932f77-c5c0-4ec7-a4fd-bab7c48e3182", false, "peter@b.com" }
                });

            migrationBuilder.InsertData(
                table: "Categories",
                columns: new[] { "CategoryId", "Description", "Title" },
                values: new object[,]
                {
                    { 1, "News covering all the world", "World News" },
                    { 2, "New covering fishing", "Fishing News" },
                    { 3, "The wors possible jokes in the world", "Joke News" }
                });

            migrationBuilder.InsertData(
                table: "DiscussionCategories",
                columns: new[] { "DiscussionCategoryId", "Description", "Name" },
                values: new object[,]
                {
                    { 1, "A forum for fishing.", "Fishing" },
                    { 2, "A forum for cars.", "Cars" },
                    { 3, "A secret forum", "Secret forum" }
                });

            migrationBuilder.InsertData(
                table: "DiscussionGroup",
                columns: new[] { "DiscussionGroupId", "DiscussionGroupName" },
                values: new object[] { 1, "The secret society." });

            migrationBuilder.InsertData(
                table: "AspNetUserRoles",
                columns: new[] { "RoleId", "UserId" },
                values: new object[,]
                {
                    { "7e1ca1bc-a0bb-4380-aac7-892d778b9de6", "fd788a3b-ae7d-46b4-a7dc-ac035df8ff94" },
                    { "71ee5627-d5d3-456c-b7be-c975cb25de70", "f8ac842f-64ad-4caf-b54f-fc964577e56d" },
                    { "37bf4465-d811-49a8-821b-40055b62de42", "3b78c692-6b1f-46e6-81fc-8705c97db0b6" }
                });

            migrationBuilder.InsertData(
                table: "DiscussionForums",
                columns: new[] { "DiscussionForumId", "Description", "DiscussionCategoryId", "Name" },
                values: new object[,]
                {
                    { 7, "If you see this, you're cool.", 3, "Secret" },
                    { 6, "German Engineering.", 2, "BMW" },
                    { 5, "They also make military aircrafts.", 2, "SAAB" },
                    { 4, "I roll.", 2, "Volvo" },
                    { 3, "A must on the christmas table.", 1, "Anchovy" },
                    { 2, "Everyone's favourite white fish.", 1, "Cod" },
                    { 1, "Everything about lobsters.", 1, "Lobster" }
                });

            migrationBuilder.InsertData(
                table: "DiscussionGroupCategory",
                columns: new[] { "DiscussionCategoryId", "DiscussionGroupId", "DiscussionGroupCategoryId" },
                values: new object[] { 3, 1, 1 });

            migrationBuilder.InsertData(
                table: "DiscussionGroupMemberships",
                columns: new[] { "CommunityUserId", "DiscussionGroupId", "CommunityUserId1", "DiscussionCategoryId", "DiscussionGroupCategoryDiscussionCategoryId", "DiscussionGroupCategoryDiscussionGroupId", "DiscussionGroupMembershipId" },
                values: new object[] { "3b78c692-6b1f-46e6-81fc-8705c97db0b6", 1, null, null, null, null, 0 });

            migrationBuilder.InsertData(
                table: "NewsPosts",
                columns: new[] { "NewsPostId", "CategoryId", "CreatedDate", "Description", "Heading", "Information", "IsEvent", "Tag", "UpdatedDate", "UserId", "UserName" },
                values: new object[,]
                {
                    { 6, 3, new DateTime(2022, 4, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "", "Bad Joke 4", "Can a dog jump higher than a house? Well, duh. Houses can’t jump !", false, "Tag", new DateTime(2022, 4, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), null, "user@b.com" },
                    { 5, 3, new DateTime(2022, 4, 18, 0, 0, 0, 0, DateTimeKind.Unspecified), "Can a dog jump higher than a house? Well, duh. Houses can’t jump.? ", "Bad Joke3", "info2", false, "Tag 3", new DateTime(2022, 4, 18, 0, 0, 0, 0, DateTimeKind.Unspecified), null, "user@b.com" },
                    { 4, 3, new DateTime(2022, 4, 18, 0, 0, 0, 0, DateTimeKind.Unspecified), "What is the most common swedish name in russian uboats? Tor-Peder", "Bad Joke2", "info2", false, "Tag 3", new DateTime(2022, 4, 18, 0, 0, 0, 0, DateTimeKind.Unspecified), null, "user@b.com" },
                    { 15, 2, new DateTime(2022, 4, 4, 0, 0, 0, 0, DateTimeKind.Unspecified), "", "Crab", "Crabs are decapod crustaceans of the infraorder Brachyura, which typically have a very short projecting tail (abdomen), usually hidden entirely under the thorax. They live in all the world's oceans, in fresh water, and on land, are generally covered with a thick exoskeleton, and have a single pair of pincers. They first appeared during the Jurassic Period.", false, "Tag", new DateTime(2022, 4, 4, 0, 0, 0, 0, DateTimeKind.Unspecified), null, "user@b.com" },
                    { 14, 2, new DateTime(2022, 4, 3, 0, 0, 0, 0, DateTimeKind.Unspecified), "", "Lobster", "Lobsters are a family (Nephropidae, synonym Homaridae) of large marine crustaceans. Lobsters have long bodies with muscular tails, and live in crevices or burrows on the sea floor.Three of their five pairs of legs have claws including the first pair, which are usually much larger than the others.Highly prized as seafood, lobsters are economically important, and are often one of the most profitable commodities in coastal areas they populate. ", false, "Tag", new DateTime(2022, 4, 3, 0, 0, 0, 0, DateTimeKind.Unspecified), null, "user@b.com" },
                    { 13, 2, new DateTime(2022, 4, 3, 0, 0, 0, 0, DateTimeKind.Unspecified), "", "Salmon", "Salmon is the common name for several species of ray-finned fish in the family Salmonidae. Other fish in the same family include trout, char, grayling, and whitefish. Salmon are native to tributaries of the North Atlantic (genus Salmo) and Pacific Ocean (genus Oncorhynchus). Many species of salmon have been introduced into non-native environments such as the Great Lakes of North America and Patagonia in South America. Salmon are intensively farmed in many parts of the world.", false, "Tag", new DateTime(2022, 4, 3, 0, 0, 0, 0, DateTimeKind.Unspecified), null, "user@b.com" },
                    { 12, 2, new DateTime(2022, 4, 2, 0, 0, 0, 0, DateTimeKind.Unspecified), "", "Pike", "The pike is a large fish that can grow over a metre in length. It is found in lakes and slow-flowing rivers and canals that have a lot of vegetation. It uses these plants as hiding places when hunting, bursting out with remarkable speed to catch fish, frogs, small mammals or ducklings. Young pike are called 'jack' and will eat small fish and invertebrates. Pike spawn between March and May, returning to the same place every year. A large female can produce up to 500,000 eggs.", false, "Tag", new DateTime(2022, 4, 2, 0, 0, 0, 0, DateTimeKind.Unspecified), null, "user@b.com" },
                    { 11, 2, new DateTime(2022, 4, 2, 0, 0, 0, 0, DateTimeKind.Unspecified), "", "Perch", "Perch is a common name for fish of the genus Perca, freshwater gamefish belonging to the family Percidae. The perch, of which three species occur in different geographical areas, lend their name to a large order of vertebrates: the Perciformes, from the Greek: πέρκη (perke), simply meaning perch, and the Latin forma meaning shape. Many species of freshwater gamefish more or less resemble perch, but belong to different genera. In fact, the exclusively saltwater-dwelling red drum is often referred to as a red perch, though by definition perch are freshwater fish. Though many fish are referred to as perch as a common name, to be considered a true perch, the fish must be of the family Percidae.", false, "Tag", new DateTime(2022, 4, 2, 0, 0, 0, 0, DateTimeKind.Unspecified), null, "user@b.com" },
                    { 2, 2, new DateTime(2022, 4, 20, 0, 0, 0, 0, DateTimeKind.Unspecified), "To mäny pots baby", "Pouching", "info2", true, "Tag 2", new DateTime(2022, 4, 20, 0, 0, 0, 0, DateTimeKind.Unspecified), null, "user@b.com" },
                    { 17, 1, new DateTime(2022, 4, 3, 0, 0, 0, 0, DateTimeKind.Unspecified), "", "What will Apple announce at WWDC 2022?", "WWDC speculation has officially begun. So, what will Apple announce at its annual developer conference in June? Macworld executive editor Michael Simon and Computerworld executive editor Ken Mingis join Juliet to discuss what to expect at WWDC this year, including updates to Apple’s operating systems like iOS and macOS and maybe even some hardware announcements.", false, "Tag", new DateTime(2022, 4, 3, 0, 0, 0, 0, DateTimeKind.Unspecified), null, "user@b.com" },
                    { 16, 1, new DateTime(2022, 4, 2, 0, 0, 0, 0, DateTimeKind.Unspecified), "", "Microsoft to kill Patch Tuesday for some enterprise users", "The company plans to launch its Windows Autopatch service for enterprise users with Windows 10 or Windows 11 Enterprise E3 licenses; it will continuously deploy patches, eliminating the need for admins to manually deploy them.", false, "Tag", new DateTime(2022, 4, 2, 0, 0, 0, 0, DateTimeKind.Unspecified), null, "user@b.com" },
                    { 10, 1, new DateTime(2022, 4, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "", "Where can I get some Lorem Ipsum?", "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.", false, "Tag", new DateTime(2022, 4, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), null, "user@b.com" },
                    { 9, 1, new DateTime(2022, 4, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "", "Why do we use Lorem Ipsum?", "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).", false, "Tag", new DateTime(2022, 4, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), null, "user@b.com" },
                    { 8, 1, new DateTime(2022, 4, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "", "Where does Lorem Ipsum come from?", "Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of de Finibus Bonorum et Malorum (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, Lorem ipsum dolor sit amet.. comes from a line in section 1.10.32. The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from de Finibus Bonorum et Malorum by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H.Rackham.", false, "Tag", new DateTime(2022, 4, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), null, "user@b.com" },
                    { 7, 1, new DateTime(2022, 4, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "", "What is Lorem Ipsum?", "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.", false, "Tag", new DateTime(2022, 4, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), null, "user@b.com" },
                    { 3, 3, new DateTime(2022, 4, 18, 0, 0, 0, 0, DateTimeKind.Unspecified), "what is grey and comes in pints?", "Bad Joke1", "info2", false, "Tag 3", new DateTime(2022, 4, 18, 0, 0, 0, 0, DateTimeKind.Unspecified), null, "user@b.com" },
                    { 1, 1, new DateTime(2022, 4, 19, 0, 0, 0, 0, DateTimeKind.Unspecified), "Biggest looser competition", "Biggest looser", "info", true, "Tag 1", new DateTime(2022, 4, 22, 8, 5, 49, 548, DateTimeKind.Local).AddTicks(7358), null, "user@b.com" }
                });

            migrationBuilder.InsertData(
                table: "DiscussionTopics",
                columns: new[] { "DiscussionTopicId", "AuthorId", "Content", "DiscussionForumId", "NrOfViews", "Subject", "Time" },
                values: new object[] { 1, "fd788a3b-ae7d-46b4-a7dc-ac035df8ff94", "Have you found your lost lobster yet? No, it's just a lost claws now.", 1, 0, "My finest lobster jokes.", new DateTime(2022, 4, 4, 7, 0, 0, 0, DateTimeKind.Unspecified) });

            migrationBuilder.InsertData(
                table: "DiscussionTopics",
                columns: new[] { "DiscussionTopicId", "AuthorId", "Content", "DiscussionForumId", "NrOfViews", "Subject", "Time" },
                values: new object[] { 2, "3b78c692-6b1f-46e6-81fc-8705c97db0b6", "Is anyone here? hello hello hello *echo*", 7, 0, "Hello I'm a lonely moderator.", new DateTime(2022, 4, 4, 7, 0, 0, 0, DateTimeKind.Unspecified) });

            migrationBuilder.InsertData(
                table: "DiscussionReplies",
                columns: new[] { "DiscussionReplyId", "AuthorId", "Content", "Time", "TopicId" },
                values: new object[] { 1, "3b78c692-6b1f-46e6-81fc-8705c97db0b6", "This is the worst joke I've ever heard in my whole life.", new DateTime(2022, 4, 4, 7, 10, 35, 0, DateTimeKind.Unspecified), 1 });

            migrationBuilder.InsertData(
                table: "DiscussionReplies",
                columns: new[] { "DiscussionReplyId", "AuthorId", "Content", "Time", "TopicId" },
                values: new object[] { 2, "f8ac842f-64ad-4caf-b54f-fc964577e56d", "As an admin, I'm banning you for this awful joke.", new DateTime(2022, 4, 4, 7, 20, 35, 0, DateTimeKind.Unspecified), 1 });

            migrationBuilder.InsertData(
                table: "DiscussionReplies",
                columns: new[] { "DiscussionReplyId", "AuthorId", "Content", "Time", "TopicId" },
                values: new object[] { 3, "3b78c692-6b1f-46e6-81fc-8705c97db0b6", "I guess I'm alone.", new DateTime(2022, 4, 4, 7, 10, 35, 0, DateTimeKind.Unspecified), 2 });

            migrationBuilder.CreateIndex(
                name: "IX_AspNetRoleClaims_RoleId",
                table: "AspNetRoleClaims",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "RoleNameIndex",
                table: "AspNetRoles",
                column: "NormalizedName",
                unique: true,
                filter: "[NormalizedName] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserClaims_UserId",
                table: "AspNetUserClaims",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserLogins_UserId",
                table: "AspNetUserLogins",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserRoles_RoleId",
                table: "AspNetUserRoles",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "EmailIndex",
                table: "AspNetUsers",
                column: "NormalizedEmail");

            migrationBuilder.CreateIndex(
                name: "UserNameIndex",
                table: "AspNetUsers",
                column: "NormalizedUserName",
                unique: true,
                filter: "[NormalizedUserName] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_DeviceCodes_DeviceCode",
                table: "DeviceCodes",
                column: "DeviceCode",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_DeviceCodes_Expiration",
                table: "DeviceCodes",
                column: "Expiration");

            migrationBuilder.CreateIndex(
                name: "IX_DiscussionForums_DiscussionCategoryId",
                table: "DiscussionForums",
                column: "DiscussionCategoryId");

            migrationBuilder.CreateIndex(
                name: "IX_DiscussionGroupCategory_DiscussionCategoryId",
                table: "DiscussionGroupCategory",
                column: "DiscussionCategoryId");

            migrationBuilder.CreateIndex(
                name: "IX_DiscussionGroupMemberships_CommunityUserId1",
                table: "DiscussionGroupMemberships",
                column: "CommunityUserId1");

            migrationBuilder.CreateIndex(
                name: "IX_DiscussionGroupMemberships_DiscussionCategoryId",
                table: "DiscussionGroupMemberships",
                column: "DiscussionCategoryId");

            migrationBuilder.CreateIndex(
                name: "IX_DiscussionGroupMemberships_DiscussionGroupCategoryDiscussionGroupId_DiscussionGroupCategoryDiscussionCategoryId",
                table: "DiscussionGroupMemberships",
                columns: new[] { "DiscussionGroupCategoryDiscussionGroupId", "DiscussionGroupCategoryDiscussionCategoryId" });

            migrationBuilder.CreateIndex(
                name: "IX_DiscussionGroupMemberships_DiscussionGroupId",
                table: "DiscussionGroupMemberships",
                column: "DiscussionGroupId");

            migrationBuilder.CreateIndex(
                name: "IX_DiscussionReplies_AuthorId",
                table: "DiscussionReplies",
                column: "AuthorId");

            migrationBuilder.CreateIndex(
                name: "IX_DiscussionReplies_TopicId",
                table: "DiscussionReplies",
                column: "TopicId");

            migrationBuilder.CreateIndex(
                name: "IX_DiscussionTopics_AuthorId",
                table: "DiscussionTopics",
                column: "AuthorId");

            migrationBuilder.CreateIndex(
                name: "IX_DiscussionTopics_DiscussionForumId",
                table: "DiscussionTopics",
                column: "DiscussionForumId");

            migrationBuilder.CreateIndex(
                name: "IX_NewsPosts_CategoryId",
                table: "NewsPosts",
                column: "CategoryId");

            migrationBuilder.CreateIndex(
                name: "IX_NewsPosts_UserId",
                table: "NewsPosts",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_PersistedGrants_Expiration",
                table: "PersistedGrants",
                column: "Expiration");

            migrationBuilder.CreateIndex(
                name: "IX_PersistedGrants_SubjectId_ClientId_Type",
                table: "PersistedGrants",
                columns: new[] { "SubjectId", "ClientId", "Type" });

            migrationBuilder.CreateIndex(
                name: "IX_PersistedGrants_SubjectId_SessionId_Type",
                table: "PersistedGrants",
                columns: new[] { "SubjectId", "SessionId", "Type" });

            migrationBuilder.CreateIndex(
                name: "IX_ReceivedPrivateMessages_ReceiverId",
                table: "ReceivedPrivateMessages",
                column: "ReceiverId");

            migrationBuilder.CreateIndex(
                name: "IX_SentPrivateMessages_SenderId",
                table: "SentPrivateMessages",
                column: "SenderId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AspNetRoleClaims");

            migrationBuilder.DropTable(
                name: "AspNetUserClaims");

            migrationBuilder.DropTable(
                name: "AspNetUserLogins");

            migrationBuilder.DropTable(
                name: "AspNetUserRoles");

            migrationBuilder.DropTable(
                name: "AspNetUserTokens");

            migrationBuilder.DropTable(
                name: "DeviceCodes");

            migrationBuilder.DropTable(
                name: "DiscussionGroupMemberships");

            migrationBuilder.DropTable(
                name: "DiscussionReplies");

            migrationBuilder.DropTable(
                name: "NewsPosts");

            migrationBuilder.DropTable(
                name: "PersistedGrants");

            migrationBuilder.DropTable(
                name: "ReceivedPrivateMessages");

            migrationBuilder.DropTable(
                name: "SentPrivateMessages");

            migrationBuilder.DropTable(
                name: "AspNetRoles");

            migrationBuilder.DropTable(
                name: "DiscussionGroupCategory");

            migrationBuilder.DropTable(
                name: "DiscussionTopics");

            migrationBuilder.DropTable(
                name: "Categories");

            migrationBuilder.DropTable(
                name: "DiscussionGroup");

            migrationBuilder.DropTable(
                name: "AspNetUsers");

            migrationBuilder.DropTable(
                name: "DiscussionForums");

            migrationBuilder.DropTable(
                name: "DiscussionCategories");
        }
    }
}
