# Project Assignment - Community Portal

See [Project Assignment - Community Portal.pdf](./Assignment/Project%20Assignment%20-%20Community%20Portal.pdf) for further information.

---
Lexicon webb development course